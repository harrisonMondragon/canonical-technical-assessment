Harrison Mondragon
October 3, 2024

This is my take home technical assessment for the Python Software Engineer - Ubuntu Server Certification
application. I chose to convert the disk_stats_test.sh to Python, and I chose to write the test case on
testing SSH connectivity. I am currently on a windows machine so I decided to use an Amazon EC2 machine
for testing, which I am unfamiliar with. My git history is messy because in order to update my code, I
pushed from local and pulled into the EC2 machine. I believe the Python conversion is very close to the
shell script, but cannot confirm entirely due to all the error handling. Thank you for the opportunity
to attempt this take home technical asessment for Canonical.

My personal git repo for this assessment is the following link:
https://github.com/harrisonMondragon/canonical-technical-assessment
